# QSI Auto - Phase 1 release

Prepared by Avia Solutions, 24 June 2026.

## What this is

The proof-of-concept QSI route forecasting tool, stood up and made portable.
Entry point `avia_qsi_auto_v3.py` (Streamlit). The forecast method is unchanged;
Phase 1 was about getting the inherited POC running and removing hardcoded paths.

## What changed in Phase 1

- The app runs: dependencies install from `requirements.txt`, all modules import,
  the portal boots, and `test_regression_v2.py` reaches the data-load step.
- Every file path now resolves through one file, `config.py`. Nothing is
  hardcoded. The Egnyte mount is detected automatically (home PC Z:, secure
  laptops P:, future Teams P:), so the same code runs on every machine with no
  path edits. `AVIA_EGNYTE_ROOT` overrides if ever needed.
- The old `/mnt/project` and `/mnt/user-data/outputs` paths are gone from all
  live code.

## The home

Canonical home is Egnyte `18 Products/QSI`. The raw Sabre and OAG master data
stay at `18 Products/Data` and are read in place, never copied. The DuckDB store
is built on a local drive and a read-only snapshot is published to
`QSI/Data Store`.

## How to run

See `RUN.txt`. In short: create a virtual environment, `pip install -r
requirements.txt`, then `streamlit run avia_qsi_auto_v3.py`. Opens at
http://localhost:8501.

## Status and the line not to cross

The BA LHR-SJC regression target is 129,162 passengers. The test fails today only
because the reference workbooks are not yet in `Reference Cases/BA LHR-SJC`. Once
they are placed, run `python test_regression_v2.py`. Until it reproduces 129,162
from the master data, treat any forecast as unproven.

## Note

The reference QSI workbook filename differs between sources: the loader expects
`QSILHR_v1_OS_JZ_17Feb15.xlsx`; the Egnyte original is
`QSI@LHR v1 (OS JZ) 17Feb15.xlsx`. Rename on placement or adjust the loader.
